package controller;

public interface IAdopcionController {
	
	public String listarMascotas(String username);

}