package controller;

public interface IMascotaController {

    public String listar(boolean ordenar, String orden);

    public String devolver(int id, String username);

    public String sumarCantidad(int id);

    public String adopcion(int id, String username);

    public String modificar(int id);

}
