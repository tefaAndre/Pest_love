package controller;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;

import com.google.gson.Gson;

import beans.Adopcion;
import connection.DBConnection;

public class AdopcionController implements IAdopcionController {

    @Override
    public String listarMascotas(String username) {

        Gson gson = new Gson();

        DBConnection con = new DBConnection();

        String sql = "Select l.id, l.titulo, l.genero, l.novedad, a.fecha from mascotas l "
                + "inner join adopcion a on l.id = a.id inner join usuarios u on a.username = u.username "
                + "where a.username = '" + username + "'";

        List<String> mascotas = new ArrayList<String>();

        try {

            Statement st = con.getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String genero = rs.getString("genero");
                boolean novedad = rs.getBoolean("novedad");
                Date fechaAdopcion = rs.getDate("fecha");

                Adopcion adopcion = new Adopcion(id, nombre, fechaAdopcion, novedad, genero);

                mascotas.add(gson.toJson(adopcion));
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }
        return gson.toJson(mascotas);
    }
}